import heapq
from Huffman import HuffmanNode
from bitarray import bitarray

def build_frequency_dict(data):
    frequency_dict = {}
    for char in data:
        if char in frequency_dict:
            frequency_dict[char] += 1
        else:
            frequency_dict[char] = 1
    return frequency_dict


def build_huffman_tree(frequency_dict):
    heap = []
    for char, frequency in frequency_dict.items():
        heapq.heappush(heap, HuffmanNode(char, frequency))

    while len(heap) > 1:
        node1 = heapq.heappop(heap)
        node2 = heapq.heappop(heap)
        merged_node = HuffmanNode(None, node1.frequency + node2.frequency)
        merged_node.left = node1
        merged_node.right = node2
        heapq.heappush(heap, merged_node)

    if heap:
        return heapq.heappop(heap)
    else:
        return None


def build_huffman_codes(huffman_tree):
    codes = {}

    def traverse(node, code):
        if node.char:
            codes[node.char] = code
        else:
            traverse(node.left, code + "0")
            traverse(node.right, code + "1")

    traverse(huffman_tree, "")
    return codes


def compress_file(input_file, output_file):
    with open(input_file, "r", encoding="utf-8") as file:
        data = file.read()

    frequency_dict = build_frequency_dict(data)
    huffman_tree = build_huffman_tree(frequency_dict)
    huffman_codes = build_huffman_codes(huffman_tree)

    compressed_data = bitarray()
    for char in data:
        compressed_data += huffman_codes[char]

    padding_length = 8 - (len(compressed_data) % 8)
    compressed_data.extend([False] * padding_length)
    padded_length = format(padding_length, "08b")
    compressed_data = bitarray(padded_length) + compressed_data

    with open(output_file, "wb") as file:
        compressed_data.tofile(file)



    print("File compressed successfully!")
    return huffman_tree



def decompress_file(input_file, output_file, huffman_tree):
    with open(input_file, "rb") as file:
        compressed_data = bitarray()
        compressed_data.fromfile(file)

    padding_length = int(compressed_data[:8].to01(), 2)
    compressed_data = compressed_data[8:-padding_length]

    current_node = huffman_tree
    decompressed_data = ""
    for bit in compressed_data:
        if bit == False:
            current_node = current_node.left
        else:
            current_node = current_node.right

        if current_node.char:
            decompressed_data += current_node.char
            current_node = huffman_tree

    with open(output_file, "w", encoding="utf-8") as file:
        file.write(decompressed_data)

    print("File decompressed successfully!")


input_file = "input.txt"
output_file = "input.compressed"

huffman_tree = compress_file(input_file, output_file)

decompress_file(output_file, "input(final).txt", huffman_tree)
